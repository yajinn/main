Official info about translation: http://codex.wordpress.org/Translating_WordPress

In two words: open default.po file and save new copy as js_composer-es_ES.po for Spanish.
And then use translating program to translate it to Spanish language.